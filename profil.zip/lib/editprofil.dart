import 'package:flutter/material.dart';

class EditProfileScreen extends StatefulWidget {
  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  TextEditingController nameController = TextEditingController();
  TextEditingController businessNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF96DDEC),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Edit Profile',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(16.0),
            child: ColorFiltered(
              colorFilter: ColorFilter.mode(
                Colors.transparent,
                BlendMode.multiply,
              ),
              child: Image.asset(
                'assets/images/user-usercircle.png',
                width: 100.0,
                height: 100.0,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Nama',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Text(
                  'Nama Usaha',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  controller: businessNameController,
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Text(
                  'Email',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 16.0,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Perform an action when "Save" is tapped
                        print('Name: ${nameController.text}');
                        print('Business Name: ${businessNameController.text}');
                        print('Email: ${emailController.text}');
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xFF96DDEC),
                        padding: EdgeInsets.symmetric(
                          vertical: 27.0,
                          horizontal: 40.0,
                        ), // Set button size
                      ),
                      child: Text(
                        'BATAL',
                        style: TextStyle(
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                    SizedBox(width: 16.0),
                    TextButton(
                      onPressed: () {
                        // Perform an action when "Cancel" is tapped
                        print('Edit canceled');
                      },
                      style: TextButton.styleFrom(
                        primary: Colors.white, // Set text color to white
                      ),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          vertical: 20.0,
                          horizontal: 40.0,
                        ),
                        decoration: BoxDecoration(
                          color: Color(0xFF96DDEC),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Text(
                          'SIMPAN',
                          style: TextStyle(
                            fontSize: 18.0,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
