import 'package:flutter/material.dart';
import 'package:profil/editprofil.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF96DDEC),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.black,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Profile',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          Container(
            alignment: Alignment.center,
            padding: EdgeInsets.all(16.0),
            child: ColorFiltered(
              colorFilter: ColorFilter.mode(
                Colors.transparent,
                BlendMode.multiply,
              ),
              child: Image.asset(
                'assets/images/user-usercircle.png',
                width: 100.0,
                height: 100.0,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Nama',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Text(
                  'Nama Usaha',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 12.0,
                ),
                Text(
                  'Email',
                  style: TextStyle(fontSize: 16.0),
                ),
                SizedBox(
                  height: 4.0,
                ),
                TextField(
                  decoration: InputDecoration(
                    hintText: '',
                  ),
                ),
                SizedBox(
                  height: 16.0,
                ),
                Align(
                  alignment: Alignment.center,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => EditProfileScreen()),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        vertical: 20.0,
                        horizontal: 140.0,
                      ),
                      decoration: BoxDecoration(
                        color: Color(0xFF96DDEC),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      child: Text(
                        'EDIT',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
